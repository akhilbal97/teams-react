## Assignment 3

This project is done using React.

## Install Dependencies

Run the command: 'npm install' on the cl

## Components used

-Multi-select from @khanacademy/react-multi-select
Run the npm command:

```
npm install --save @khanacademy/react-multi-select
```
- Design libraries used: @material-ui and material-ui
Run the npm commands:
```
npm install --save @material-ui/core
```   
```
npm install --save material-ui
```   

## Tools used

- eslint
```
npm run eslint
```   

-prettier
```
npm run prettier
```   
## Bugs

- Cannot update the values in teams-api

